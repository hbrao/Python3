from setuptools import setup,find_packages

setup(
    name='pyds',
    version='1.0',
    description='Python Data Structures',
    author='Hanumantha Rao Banda',
    author_email='hanu.16aug@outlook.com',
    url='www.myrobot.com',
    packages=find_packages()
)