class LinkedNode:
    def __init__(self, value=None, tail=None):
        """Node in a linked list"""
        self.value = value
        self.next = tail